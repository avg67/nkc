#define NKC YES

#if defined(NKC)

	//fixes for bugs in libgcc.a wrt relocation
//	#include "../libs/libc/divsi3.h"   
//	#include "../libs/libc/umodsi3.h"
//	#include "../libs/libc/mulsi3.h"

	#include <stdlib.h>
	#include <stdio.h>
	#include <string.h>
	#include <math.h>
	#include "../../nkc_common/nkc/nkc.h"


	//#include "../libs/standAloneHeader.h"
#if 0
	//NKC bibl header
	__asm__("dc.b 0x55, 0xAA, 0x01, 0x80");
	__asm__("dc.b 'S', 'P', 'A', 'C', 'I', 'N', 'V', '1' ");
	__asm__("dc.l _start");  	//
	__asm__("dc.l _bss_end");	//from likerscript
	__asm__("dc.b 0x01");
	__asm__("dc.b 0x01");
	__asm__("dc.b 0x00, 0x00");
	__asm__("dc.l 0x00");
#endif
#endif

void processJoystick();
void processKeyboard();
int getRandom();

#define simulatePlayer FALSE

#include "NKC_UTIL.h"

typedef enum {UNDEF = 0xFF, MONSTER=1, UP_FIRE=2, DOWN_FIRE=3, BUNKER=4, PLAYER=5, UFO=6, TEXT=7, BANG=8, FLASHTEXT=9} OBJECT_TYPE;


int counter = 0;
int noOfMonstersAlive = 0;

typedef struct GameStats
{
	int noOfLives;
	int level;
	int score;
	int highScore;
} GameStats;
GameStats gameStats;

typedef struct DynVisObj   //21 bytes
{
	byte type;	
	byte score;	  
	byte isDirty[2];
	word alive[2];    //also used to handle life-span, decrease to zero
	word xPos;     
	word yPos;

	byte displayGroup;  

	byte actCmdList;     //index of cmd list to draw
	byte *cmdList[2];    //32bit int pointer to a byte (array)

	word xPosPage[2]; 
	word yPosPage[2];
	byte *cmdListPage[2];   

	byte accel;          //acceleration, only for up-bullets

} DynVisObj;


word MAX_NO_DYN_OBJ = 100;
word noOfDynObj = 1;
DynVisObj listDyn[200];   

typedef struct StatVisObj  //12 bytes
{
	int type;
	byte isDirty[2];
	word alive;   
	word xPos;     
	word yPos;
	byte *cmdList;  
} StatVisObj;

word MAX_NO_STAT_OBJ = 100;
word noOfStatObj = 1;        //why not 0 ?
StatVisObj listStat[200];

int tick = 0;
int frame = 0;
int counts = 0;

int noOfInvadersInRow = 11;
int noOfInvaderRows = 5;

int monsterHeight = 8;
int monsterWidth = 19;	//not true for all monster
int UFOwidth = 32;

int noOfBunkerBlocksX = 6;
int noOfBunkerBlocksY = 4;

int bunkerBlockHeight = 4;  
int bunkerBlockWidth = 8;

int direction = 1;
int gameOn = TRUE;

int toggle = 0;

int xStepSize = 0;    
int xStepSizeSteps[6] = {3, 4, 5, 6, 7, 7};

int yStepSize = -16;  //-16

word xPosPlayer = 0;   //245
word yPosPlayer = 14;

//Monsterstats
int maxX = 0;
int minX = 999;
int minY = 999;

int UFOxPos = 0;
int UFOyPos = 225;
int monsterStartY = 210;

int moveMonster = FALSE;
int restartLevel = FALSE;
int UFOactive = FALSE;
int UFOdirection = -1;

word bounceRight = 490;
word bounceLeft = 10;
word bounceLow = 14;  //end the game when Monster reach this low

int idxOfMosterThatLastFired = -99;

byte key = 0x00;

byte heartBeatSound = 0;

int enemyFireProbs[6] = {96, 92, 85, 80, 75, 70};

int maxCountsPerHSYNC;

int measureFramerate = FALSE;

int lastTickFired = 0;        //check frames since last fired

int addDynObj(OBJECT_TYPE obj_type, int x, int y, byte* cmds);
void printDynVisObjList();

#include "NKC_GDP64.h"
#include "NKC_SOUND.h"

byte emptyList[2] = {0x00, 0x00};

//#define SIMPLEMONSTER 

//#if SIMPLEMONSTER
//byte monsterA1[14] = {v3NE, v3NN, v3NN, v3EE, v3EE, v3EE, v3SS, v3SS, v3SE, v3NW, v3WW, v3WW, v3WW, 0x00};
//byte monsterA2[18] = {vUP, v3NE, vDOWN, v3SE, v3NW, v3NN, v3NN, v3EE, v3EE, v3EE, v3SS, v3SS, v3SW, v3NE, v3WW, v3WW, v3WW, 0x00};

//byte monsterB1[12] = {v3NE, v3NN, v3NE, v2EE, v3SE, v3SS, v3SE, v3NW, v3WW, v3WW, v2WW, 0x00};
//byte monsterB2[20] = {vUP, v3NE, vDOWN, v3SE, v3NW, v3NN, v3NE, v2EE, v3SE, v3SS, v3SW, v3NE, v3WW, v3WW, v2WW, 0x00};   
//#else						


static const byte Bang[58] = {v1EE, v1NE, v1EE, v1NE, v1EE, 0x03, v3EE, v1SS, 0x02, v1SS, v1EE, v1NN, 0x03, v1NE, v2EE, 0x02,
                 v1EE, v1SE, v1EE, v1SE, v1EE, 0x03, v3NN, 0x02, v2WW, 0x03, v3WW, v1NN, 0x02, v1EE, v1NE, v1EE,
                 v1NE, v1EE, 0x03, v3WW, v3WW, v2WW, 0x02, v1SS, v1WW, v1NN, 0x03, v3WW, v3WW, v2WW, 0x02, v1EE,
                 v1SE, v1EE, v1SE, v1EE, 0x03, v1SW, v2WW, 0x02, v2WW, 0x00};

static const byte UFOA[85] = {vUP, v2NN, vDOWN, v3EE, v1SE, v2EE, v1SS, v1EE, v1NN, v2EE, v1NE, v3EE, v1SE, v3EE, v1NE, v3EE, v1SE,
                 v2EE, v1SS, v1EE, v1NN, v2EE, v1NE, v3EE, v1WW, v1NW, v1WW, v1NW, v2SS, v3WW, v2WW, v1NN,
                 v2WW, v1NW, v1WW, v1SW, v1SS, v3WW, v2NN, v3WW, v1SS, v2WW, v1SS, v3WW, v2WW, v1NW, v1WW,
                 v3EE, v1NW, v3EE, v1SE, v1NN, v1NW, v1WW, v3EE, v1SS, v1EE, v1NN, v3EE, v2EE, v2SS, v1EE,
                 v1NN, v1EE, v1NE, v2EE, v1SS, v3EE, v1SS, v1NN, v3EE, v1SS, v1NN, v1WW, v1NW, v3WW, v1WW,
                 v1NW, v2WW, v1SS, v1WW, v1NN, v3WW, v1WW, 0x00};

static const byte monsterA1[51]   = {vUP, v1NN, vDOWN, v1SE, v2EE, v1WW, v1NW, v1NE, v1EE, v1NN, v3WW, v1NN, v3EE, v1NW, v2EE, 
						v1NN, v2EE, v1NN, v3EE, v1SS, v2WW, v1SE, v3WW, v1EE, v2SS, v2WW, v3EE, v1SW, v3EE, v2NW, 
						v2EE, v1SS, v3EE, v1SS, v1EE, v1SE, v1EE, v1SW, v2WW, vUP, v3NN, vDOWN, v3EE, v1NN, v3WW, 
						v1NE, v3WW, v1WW, v1NE, v1EE, 0x00}; 

static const byte monsterA2[51]   = {v1EE, v1NE, v1EE, v1SE, v1EE, v1NE, v3EE, v1SE, v1EE, v1NE, v1EE, v1SE, v1EE, vUP, v3NN, 
						vDOWN, v3WW, v1SW, v1WW, v1NE, v3WW, v3WW, v1SS, v1WW, v1NN, v3WW, v1WW, v1NN, v3EE, v1NW, 
						v2EE, v1NN, v1EE, v1SS, v1SE, v3EE, v1NE, v3EE, v1SE, v1EE, v3WW, v1NW, v1NN, v2WW, v1NN, 
						v3WW, v2SS, v3EE, v1NW, v1WW, 0x00};

static const byte monsterB1[60]   = { 
	vUP, v1NN, vDOWN, v2NN, v1EE, v1NN, v1EE, v1SS, v1EE, v2NN, v1EE, v3SS, v1SS, v1EE, v1SE, v2EE, vUP, v2EE,
  	vDOWN, v2EE, v1NE, v1EE, v1NN, v3WW, v3WW, v3WW, v1NN, v3EE, v3EE, v3EE, v3EE, v1EE, v2SS, v2NN, v1NW, v3WW,
  	v1NE, v1WW, v1SW, v2NN, v1NE, v1EE, v1WW, v1SW, v1WW, v1SS, v2WW, v1SS, v2WW, v1NE, v3WW, v1SW, v2NN, v1EE, 
  	v1WW, v1NW, v1WW, 0x00};

static const byte monsterB2[62]   = {
	vUP, v3NN, vDOWN, v3NN, v2SS, v1EE, v1SS, v1EE, v1NN, v1NE, v2SS, v1SE, v3NN, v1NE, v1NW, v1WW, v1EE, v1SE, 
 	v3SS, v3SS, v1WW, v1NE, v1EE, v2NN, v1EE, v1SS, v3EE, v1EE, v2SE, v1EE, v3NW, v2EE, v1SS, v1EE, v1NN, v3EE, 
 	v1EE, v3NN, v2SS, v3WW, v1NN, v1WW, v1SS, v1WW, v2NN, v1NE, v1EE, v1WW, v1SW, v1WW, v1SS, v2WW, v2SS, v2WW, 
 	v1NN, v1EE, v1NN, v3WW, v1NN, 0x00};

static const byte monsterC1[50] = {
	v1EE, v1NE, v1EE, v1NE, v1EE, v2NN, v3EE, v3EE, v1EE, v2SS, v1EE, v1SE, v1EE, v1SE, v1EE, 
	0x03, v3NN, 0x02, v2NN, v1WW, v2SS, v3WW, v3WW, v3WW, v3WW, v2WW, v1NN, v1WW, v1SS, v1WW, 
	v2NN, v3EE, v3EE, v1EE, v1NE, v1EE, v1SE, v3EE, v1EE, v1SE, v1NN, v1NW, v2WW, v1NW, v3WW, 
	v2WW, v1SW, v2WW, 0x00};

static const byte monsterC2[52] = {
	0x03, v3EE, v2EE, 0x02, v1WW, v1NW, v1WW, v1EE, v1NE, v1EE, v2NN, v3EE, v3EE, v1EE, v2SS,
	v1EE, v1SE, v1EE, v1WW, v1SW, v1WW, 0x03, v3NN, 0x02, v3EE, v2EE, v2NN, v1WW, v1SS, v1WW,
	v1NN, v3WW, v3WW, v3WW, v3WW, v3WW, v2SS, v1EE, v1NN, v1EE, v1SS, v3EE, v3EE, v3EE, v3NN,
	v3EE, v3WW, v3WW, v3WW, v2WW, 0x00};

static const byte bottomBang[21] = {
	v3NN, v1WW, v3SS, v2WW, v1NW, v1WW, v1NW, v1WW, 0x03, v3EE, v3EE, v3EE, v3EE, v1EE, 0x02,
	v2WW, v1SS, v1WW, v1SW, v2WW, 0x00};

static const byte fire[14]    = {v3SS, 0x00};
static const byte upFire[2]   = {v3SS, 0x00};   //fuse is up
static const byte downFire[2] = {v3NN, 0x00};   //fuse is down


static const byte player[44]    = {0x0a, 0x03, v3WW, v3WW, v3WW, v3WW, v3WW, v3WW, v3WW, v3NN, vDOWN, v3NN, v1NN, v3NW, v3SW, 
					  vERASE, 0x03, v3WW, v3WW, v3WW, v3WW, v3WW, vDOWN, v2WW, v1SS, 
					  0x03, v3EE, v3EE, v3EE, v3EE, v3EE, v3EE, v3EE, v3EE, v3EE, v3EE, v3EE, v3EE,
					  v1NN, vDOWN, v1NN, v2WW,


					  0x00};

static const byte bunker[2]     = {0x0b, 0x00};  //8x4 block
byte text_level[10] = {0x4c, 0x45, 0x56, 0x45, 0x4c, 0x20, 0x00, 0x00, 0x00, 0x00};  //"LEVEL " and some 0x00
static const byte text_blank[10] = {0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x00};

static const byte text_topLine[22] = {0x53, 0x43, 0x4F, 0x52, 0x45, 0x3c, 0x31, 0x3e, 0x20, 0x20, 0x20, 0x48, 0x49, 
			      0x2d, 0x53, 0x43, 0x4F, 0x52, 0x45, 0x20, 0x00}; //SCORE<1> HI-SCORE

static const byte text2_botLine[12] = {0x43, 0x52, 0x45, 0x44, 0x49, 0x54, 0x20, 0x30, 0x30, 0x20,  0x00}; //CREDIT

byte text_score[6]        = {0x30, 0x30, 0x30, 0x30, 0x00};
byte text_highScore[6]    = {0x30, 0x30, 0x30, 0x30, 0x00};
byte text_score_blanks[6] = {0x0a, 0x0a, 0x0a, 0x0a, 0x00};

byte flash_text[4]        = {0x30, 0x30, 0x30, 0x00};
byte flash_text_blanks[4] = {0x0a, 0x0a, 0x0a, 0x00};

static const byte numbers[22] = {0x30, 0x00, 0x31, 0x00, 0x32, 0x00, 0x33, 0x00, 0x34, 0x00, 0x35, 0x00, 0x36, 0x00, 0x37, 0x00, 0x38, 0x00, 0x39, 0x00, 0x40, 0x00};


int joystickAccel = 0;
int joystickAccelInc = 1;

int minJoystickAccel = 1;
int maxJoystickAccel = 1;
int joystickFireAllowed = TRUE;
int joystickRamp = 0;			//min iterations before joystick acc kicks in

static const int dauerfeuerpreventSteps[6] = {7, 6, 5, 4, 3, 0};
int dauerfeuerprevent = 7;

void doJoystickRight() {
  xPosPlayer+=joystickAccel;
}

void doJoystickLeft() {
  xPosPlayer-=joystickAccel;
}

void doJoystickFire() {
	
	addToSoundBuffer(&soundBufferA, sound_upFire_ChannelB, sizeof(sound_upFire_ChannelB));
	addDynObj(UP_FIRE, xPosPlayer+18, 20, (byte *)&fire); 
}

#include "NKC_JOYSTICK.h"


//********************************************************************************************************************
// Interrupt handling
//********************************************************************************************************************

//section .interrupt set as per linker script location is known: _int_handler_sta
//void  __attribute__((interrupt)) __attribute__((section(".interrupt"))) int_handler_func() {
	
	//debug();
	//WAIT(1000);
//}

//********************************************************************************************************************
// DynArray
//********************************************************************************************************************

int getNoOfDynObj(OBJECT_TYPE obj_type) {

	int count = 0;

	for (int i=0; i <= noOfDynObj; i++) { 
		if(listDyn[i].type == obj_type) {
			count++;
		}
	}

	return count;
}

int addDynObj(OBJECT_TYPE obj_type, int x, int y, byte* cmds) { //add dg parameter
	
	int i = 0;

	for (i=0; i <= noOfDynObj+1; i++) { 

		if (listDyn[i].type == UNDEF) {

				listDyn[i].type = obj_type; 
				listDyn[i].isDirty[0] = TRUE;
				listDyn[i].isDirty[1] = TRUE;

				listDyn[i].alive[0] = TRUE;
				listDyn[i].alive[1] = TRUE;
				
				listDyn[i].xPos = x;     
				listDyn[i].yPos = y;			

				listDyn[i].xPosPage[0] = x; 
				listDyn[i].xPosPage[1] = x;   

				listDyn[i].yPosPage[0] = y;
				listDyn[i].yPosPage[1] = y;

				listDyn[i].displayGroup = 10;  //NOTE: this is the default

				listDyn[i].actCmdList = 0;  

				listDyn[i].cmdList[0] = cmds;         
				listDyn[i].cmdListPage[0] = cmds;   
				listDyn[i].cmdListPage[1] = cmds;   

				listDyn[i].accel = 1;

				if (obj_type == UFO) {
					listDyn[i].score = (getRandom() / 25) + 1;  //1...5
				}

				break;
  		}
	}

	if (i > noOfDynObj) {noOfDynObj++;}
	//DebugPrint("_", noOfDynObj, DEC);
	//PRINT2(10, 6, noOfDynObj);	
	return i;	
}

void initObj() {

	//clean dyn list
   for (int i=0; i < MAX_NO_DYN_OBJ; i++) {
   	 listDyn[i].type = UNDEF;
   	 listDyn[i].score = 0;
   	 listDyn[i].isDirty[0] = FALSE;
 	 listDyn[i].isDirty[1] = FALSE;
	 listDyn[i].alive[0] = FALSE;       
	 listDyn[i].alive[1] = FALSE;
 	 listDyn[i].xPosPage[0] = 0;       
	 listDyn[i].yPosPage[0] = 0;
	 listDyn[i].xPosPage[1] = 0;       
	 listDyn[i].yPosPage[1] = 0;
	 listDyn[i].actCmdList = 0;  
	 listDyn[i].cmdListPage[0] = (byte *)(&emptyList);
	 listDyn[i].cmdListPage[1] = (byte *)(&emptyList);
   }

   //clean stst list
   for (int i=0; i < MAX_NO_STAT_OBJ; i++) {  //not compiled
   	 listStat[i].type = UNDEF;
   	 listStat[i].isDirty[0] = FALSE;
   	 listStat[i].isDirty[1] = FALSE;
   	 listStat[i].alive = FALSE;
   	 listStat[i].cmdList = (byte *)(&emptyList);
   }

   int Y_adjustment = gameStats.level * 10;
   if (Y_adjustment > 50) {Y_adjustment = 50;}

   //configure dynList with init screen, monster, bunker, player
   int i = 0;

   //Monster
   for (int iY=noOfInvaderRows-1; iY >= 0; iY--) {  //sure?

		for (int iX=0; iX < noOfInvadersInRow; iX++) { 
		
		 listDyn[i].type = MONSTER;
		 listDyn[i].score = 20;
		 listDyn[i].isDirty[0] = FALSE;
		 listDyn[i].isDirty[1] = FALSE;

		 listDyn[i].alive[0] = TRUE;       
		 listDyn[i].alive[1] = TRUE;

		 listDyn[i].xPos = (iX * 30) + 100;  //TEST 
		 listDyn[i].yPos = monsterStartY - (iY * 16) - Y_adjustment;  
		
 		 listDyn[i].xPosPage[0] =  listDyn[i].xPos;
		 listDyn[i].xPosPage[1] =  listDyn[i].xPos;
 		 listDyn[i].yPosPage[0] =  listDyn[i].yPos;
		 listDyn[i].yPosPage[1] =  listDyn[i].yPos;

		 listDyn[i].displayGroup = iY + 1;   //each line is a display group starting at 1, not 0

		 listDyn[i].actCmdList = 0;   //use first entry in below list for display 		 
 		 listDyn[i].cmdList[0] = (byte *)(&monsterB1);
		 listDyn[i].cmdList[1] = (byte *)(&monsterB2); 

		 if (iY == 0) {
 		   listDyn[i].score = 30;
		   listDyn[i].cmdList[0] = (byte *)(&monsterA1);
		   listDyn[i].cmdList[1] = (byte *)(&monsterA2); 
		 }

		 if (iY > 2) {
		   listDyn[i].score = 10;
		   listDyn[i].cmdList[0] = (byte *)(&monsterC1);
		   listDyn[i].cmdList[1] = (byte *)(&monsterC2); 
		 }

		 i++;
	  }
	}
	
	//Player
	listDyn[i].type = PLAYER;
	listDyn[i].isDirty[0] = FALSE;
	listDyn[i].isDirty[1] = FALSE;
 	listDyn[i].alive[0] = TRUE;   
 	listDyn[i].alive[1] = TRUE;
	
	listDyn[i].xPos = xPosPlayer; 
	listDyn[i].yPos = yPosPlayer;

	listDyn[i].displayGroup = -1;
	listDyn[i].actCmdList = 0;  
	listDyn[i].cmdList[0] = (byte *)(&player); 
	listDyn[i].cmdList[1] = (byte *)(&player); 
		
	noOfDynObj = i;  //end
	
	//configure statList with init screen items, Bunkerblocks 96 pieces
	int xBunker = 80;
	int yBunker = 44;

	i = 0;
	for (int b=0; b < 4; b++) {  
		for (int iX=0; iX < noOfBunkerBlocksX; iX++) { 
    	  	for (int iY=0; iY < noOfBunkerBlocksY; iY++) { 

      			listStat[i].type = BUNKER;
      			listStat[i].isDirty[0] = TRUE;
      			listStat[i].isDirty[1] = TRUE;

		 		listStat[i].alive = TRUE;       
		
				listStat[i].xPos = xBunker + (8 * iX);  
		 		listStat[i].yPos = yBunker - (4 * iY);
		
		 		listStat[i].cmdList = (byte *)(&bunker); 
		 		i++;
	      	}
 		}
 		xBunker += 110;
 	}
 	//swich ccorners of bunker off
 	listStat[0   ].alive = FALSE; listStat[11   ].alive = FALSE; listStat[15   ].alive = FALSE; listStat[20   ].alive = FALSE; 
	listStat[0+24].alive = FALSE; listStat[11+24].alive = FALSE; listStat[15+24].alive = FALSE; listStat[20+24].alive = FALSE; 
	listStat[0+48].alive = FALSE; listStat[11+48].alive = FALSE; listStat[15+48].alive = FALSE; listStat[20+48].alive = FALSE; 
	listStat[0+72].alive = FALSE; listStat[11+72].alive = FALSE; listStat[15+72].alive = FALSE; listStat[20+72].alive = FALSE; 

	// score
	listStat[i].type = TEXT;
	listStat[i].alive = TRUE;       
	listStat[i].xPos = 20;  
	listStat[i].yPos = 238;
	listStat[i].cmdList = (byte *)(&text_score);
	i++;

	//high score
	listStat[i].type = TEXT;
	listStat[i].alive = TRUE;       
	listStat[i].xPos = 234;  
	listStat[i].yPos = 238;
	listStat[i].cmdList = (byte *)(&text_highScore);
	//i++; DO NOT

 	noOfStatObj = i;  //end
}

void drawStatObj() {

 	for (int i=0; i <= noOfStatObj; i++) {  //uhhh, really? why <=

   		catchSync();

   		StatVisObj* e = &listStat[i];

   		switch (e->type) {

			case (BUNKER):
	  			GDP_CSIZE(0x21);
	  			if (e->isDirty[NKClib_page] == TRUE) { 
		  			if (e->alive == TRUE) { 
	         			CMDPRINT3(e->xPos, e->yPos, e->cmdList);
		  			} else {
		  				CMD(0x01);
		  				CMDPRINT3(e->xPos, e->yPos, e->cmdList);
		  				CMD(0x00);	
		  			}
		  			e->isDirty[NKClib_page] = FALSE;
	  			}
	  		break;

	  		case (TEXT):
	  			GDP_CSIZE(0x31);
  				CMD(0x01);
				CMDPRINT3(e->xPos, e->yPos, (byte *)&text_score_blanks);
				CMD(0x00);
				CMDPRINT3(e->xPos, e->yPos, e->cmdList);
	  		break;

   		 	//case UNDEF:
   		 		//PRINT2(250, 118, 0xBBBB); PRINT2(310, 118, e->type); PRINT2(370, 118, i);
   			//break;
   		}

   	}
}

void __attribute__ ((noinline)) drawDynObj() {

	GDP_CSIZE(0x21);

 	//int count = 0;

	for (int i=0; i <= noOfDynObj; i++) {  
   		
		if (i==10) 	processJoystick();
		if (i==15) 	processJoystick();
		if (i==20) 	processJoystick();
		if (i==25) 	processJoystick();
		if (i==30) 	processJoystick();
		if (i==35) 	processJoystick();
		if (i==40) 	processJoystick();
		if (i==45) 	processJoystick();
		if (i==50) 	processJoystick();
		if (i==55) 	processJoystick();
		if (i==60) 	processJoystick();

	   		catchSync();

	   		DynVisObj* e = &listDyn[i];
	   		
	   		switch (e->type) {

	   		 	//case UNDEF:
	   		 	//	DebugPrintPos(256, 128, __FILE__, __LINE__, DEC);
	   			//break;

	   			case MONSTER:
		  			if (e->alive[NKClib_page] == TRUE) { 
	         			if (e->isDirty[NKClib_page] == TRUE) {
		         			CMDPRINT3(e->xPos, e->yPos, e->cmdList[e->actCmdList]);	
				 			e->xPosPage[NKClib_page] = e->xPos;
			     			e->yPosPage[NKClib_page] = e->yPos;
			     			e->cmdListPage[NKClib_page] = e->cmdList[e->actCmdList]; 
			     			e->isDirty[NKClib_page] = FALSE;
		     			}
		  			}
		  			break;

				case (UP_FIRE):
		  			if (e->alive[NKClib_page] == TRUE) { 
	         			CMDPRINT3(e->xPos, e->yPos, e->cmdList[0]);
			 			e->xPosPage[NKClib_page] = e->xPos;
		     			e->yPosPage[NKClib_page] = e->yPos;
						e->cmdListPage[NKClib_page] = e->cmdList[0];
		  			}
		  			break;

				case (DOWN_FIRE):
		  			if (e->alive[NKClib_page] == TRUE) { 
	         			CMDPRINT3(e->xPos, e->yPos, e->cmdList[0]);
			 			e->xPosPage[NKClib_page] = e->xPos;
		     			e->yPosPage[NKClib_page] = e->yPos;	
						e->cmdListPage[NKClib_page] = e->cmdList[0];	
		  			}
		  			break;

				case (PLAYER):
		  			if (e->alive[NKClib_page] == TRUE) { 
 						GDP_CSIZE(0x71);
	         			CMDPRINT3(xPosPlayer, e->yPos, e->cmdList[0]);
	         			CMD(0x00);
			 			e->xPosPage[NKClib_page] = xPosPlayer; //different
		     			e->yPosPage[NKClib_page] = e->yPos;	
		     			e->cmdListPage[NKClib_page] = e->cmdList[0];
 						GDP_CSIZE(0x21);
		  			}
		  			break;

				case (UFO):
					if (e->alive[NKClib_page] == TRUE) { 
						CMDPRINT3(e->xPos, e->yPos, e->cmdList[0]);
						e->xPosPage[NKClib_page] = e->xPos;
			     		e->yPosPage[NKClib_page] = e->yPos;	
						e->cmdListPage[NKClib_page] = e->cmdList[0];	
					}
					break;

				case (BANG):
					if (e->alive[NKClib_page] == TRUE) { 
						GDP_CSIZE(0x11);
						CMDPRINT3(e->xPos, e->yPos, e->cmdList[0]);
						e->xPosPage[NKClib_page] = e->xPos;
				     	e->yPosPage[NKClib_page] = e->yPos;	
						e->cmdListPage[NKClib_page] = e->cmdList[0];	
						
						e->alive[!NKClib_page] = FALSE;  //temporary object undisplay next frame
					}
					break;

				case (FLASHTEXT):
					if (e->alive[NKClib_page] == TRUE) { 
						GDP_CSIZE(0x11);
						CMDPRINT3(e->xPos, e->yPos, e->cmdList[0]);
						e->xPosPage[NKClib_page] = e->xPos;
				     	e->yPosPage[NKClib_page] = e->yPos;	
						e->cmdListPage[NKClib_page] = e->cmdList[0];	
						
						e->alive[!NKClib_page] = FALSE;  //temporary object undisplay next frame
					}
					break;

				//default:  
					//DebugPrintPos(256, 128, __FILE__, __LINE__, DEC);
				
			}
	  	//}
   }
}

void clearDynObj() {

   CMD(0x01);
   GDP_CSIZE(0x41);

   for (int i=0; i <= noOfDynObj; i++) {  
   		
		if (i==10) 	processJoystick();
		if (i==15) 	processJoystick();
		if (i==20) 	processJoystick();
		if (i==25) 	processJoystick();
		if (i==30) 	processJoystick();
		if (i==35) 	processJoystick();
		if (i==40) 	processJoystick();
		if (i==45) 	processJoystick();
		if (i==50) 	processJoystick();
		if (i==55) 	processJoystick();
		if (i==60) 	processJoystick();

		catchSync();

   		DynVisObj* e = &listDyn[i];

		switch (e->type) {

   			//case UNDEF:
   				//DebugPrintPos(256, 128, __FILE__, __LINE__, DEC);
   			    //break;

   			case (MONSTER):
				if (e->isDirty[NKClib_page] == TRUE) {
					GDP_BLANK(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page]);  
					//CMDPRINT3(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page], e->cmdListPage[NKClib_page]);
					if ((e->alive[NKClib_page] == FALSE) && (e->alive[!NKClib_page] == FALSE)) {e->type = UNDEF; }
					if (e->alive[NKClib_page] == FALSE) e->alive[!NKClib_page] = FALSE;
				}
				break;

			case (UP_FIRE):
				CMDPRINT3(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page], e->cmdListPage[NKClib_page]);
				if ((e->alive[NKClib_page] == FALSE) && (e->alive[!NKClib_page] == FALSE)) {e->type = UNDEF; }
				if (e->alive[NKClib_page] == FALSE) e->alive[!NKClib_page] = FALSE;	
				break;

			case (DOWN_FIRE):
				CMDPRINT3(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page], e->cmdListPage[NKClib_page]);
				if ((e->alive[NKClib_page] == FALSE) && (e->alive[!NKClib_page] == FALSE)) {e->type = UNDEF; }
				if (e->alive[NKClib_page] == FALSE) e->alive[!NKClib_page] = FALSE;	
				break;

			case (PLAYER):
 				GDP_CSIZE(0x71);
				CMDPRINT3(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page], e->cmdListPage[NKClib_page]);
				CMD(0x01);
				//if ((e->alive[NKClib_page] == FALSE) && (e->alive[!NKClib_page] == FALSE)) {e->type = UNDEF; }
				//if (e->alive[NKClib_page] == FALSE) e->alive[!NKClib_page] = FALSE;	
 				GDP_CSIZE(0x21);
				break;

			case (UFO):
				CMDPRINT3(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page], e->cmdListPage[NKClib_page]);
				if ((e->alive[NKClib_page] == FALSE) && (e->alive[!NKClib_page] == FALSE)) {e->type = UNDEF; UFOactive=FALSE;}
				if (e->alive[NKClib_page] == FALSE) e->alive[!NKClib_page] = FALSE;	
				break;

			case (BANG):
				CMDPRINT3(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page], e->cmdListPage[NKClib_page]);
				if ((e->alive[NKClib_page] == FALSE) && (e->alive[!NKClib_page] == FALSE)) {e->type = UNDEF;}
				if (e->alive[NKClib_page] == FALSE) e->alive[!NKClib_page] = FALSE;	
				break;

			case (FLASHTEXT):
				//CMDPRINT3(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page], e->cmdListPage[NKClib_page]);
				CMDPRINT3(e->xPosPage[NKClib_page], e->yPosPage[NKClib_page], &flash_text_blanks[0]);
				if ((e->alive[NKClib_page] == FALSE) && (e->alive[!NKClib_page] == FALSE)) {e->type = UNDEF;}
				if (e->alive[NKClib_page] == FALSE) e->alive[!NKClib_page] = FALSE;	
				break;

			//default:
				//DebugPrintPos(256, 128, __FILE__, __LINE__, DEC);
			}
		//}
	}
    CMD(0x00);
}

int hitBunker(int fireX, int fireY, int bunkerX, int bunkerY) {

 	if ((fireX >= bunkerX) && (fireX < bunkerX+bunkerBlockWidth)) {

		//fire not yet reached bunker
		if (fireY > bunkerY+bunkerBlockHeight) {
			return 0;
		}
		return 1;
	}
  	return 0;
}

int hitMonster(int fireX, int fireY, int monsterX, int monsterY) {
                
 	if ((fireX >= monsterX) && (fireX <= monsterX+monsterWidth)) {

		//fire not yet reached monster
		if (fireY < monsterY) {
			return 0;
		}
	return 1;
  }
  return 0;
}

int hitUFO(int fireX, int fireY, int UFOX, int UFOY) {
                
 	if ((fireX >= UFOX) && (fireX <= UFOX+UFOwidth)) {

		//fire not yet reached monster
		if (fireY < UFOY) {
			return 0;
		}
	return 1;
  }
  return 0;
}

//*********************************************************************************************
// doAction
//*********************************************************************************************

void godKonwsWhy() {

	for (int i=0; i <= noOfDynObj; i++) {
  		if (listDyn[i].type == MONSTER) {
			if (listDyn[i].displayGroup == 5) {
  			  listDyn[i].isDirty[!NKClib_page] = TRUE;
  			}
  		}
  	}
}


void doSpecialEffects() {

	//do 4 step heart beat
	heartBeatSound++;
  	heartBeatSound = heartBeatSound % 4;
  	addToSoundBuffer(&soundBufferA, pock_sounds[heartBeatSound], sizeof(pock_soundA));

  	//flip monster sprite
  	for (int i=0; i <= noOfDynObj; i++) {
  		if (listDyn[i].type == MONSTER) {
			listDyn[i].actCmdList = !listDyn[i].actCmdList;
  		}
  	} 
}

#include "console.h"

void doAction() {  
  
  //do game logic    
  if (noOfMonstersAlive == 0) {
  	gameStats.level++;
  	restartLevel = TRUE;
  }

  if (gameStats.noOfLives == 0) gameOn = FALSE;  //again ???
  
  //generate enemy fire
  int enemyFireThreshold = 0;
  if (gameStats.level <= 5)  {
  	enemyFireThreshold = enemyFireProbs[gameStats.level-1];
  	xStepSize = xStepSizeSteps[gameStats.level-1];
  	dauerfeuerprevent = dauerfeuerpreventSteps[gameStats.level-1];
  } else {
  	enemyFireThreshold = enemyFireProbs[5];
  	xStepSize = xStepSizeSteps[5];
  	dauerfeuerprevent = dauerfeuerpreventSteps[5];
  }

  if (getRandom() > enemyFireThreshold) {

    //select column
    int startIndex = ((getRandom()+10) / 10);  //10..110  ->  1..11
    int lastCol = startIndex + (4 * 11);
    int found = FALSE;

    int idx = startIndex;
    while (!found) {
    	if (listDyn[idx].type == MONSTER) {
			if (listDyn[idx].alive[NKClib_page] == TRUE) {
				if (idx != idxOfMosterThatLastFired) {   //avoids Monster shooting twice in a a row
					addDynObj(DOWN_FIRE, listDyn[idx].xPos+9, listDyn[idx].yPos-3, (byte *)(&downFire));
					found = TRUE;
					idxOfMosterThatLastFired = idx;
				}
			}
		}
		idx = idx + 11;
		if (idx == lastCol) found = TRUE;
    }
  }
}

void doMovements(int dg) {

  //do movements
  for (int i=0; i <= noOfDynObj; i++) {
    
	if ((listDyn[i].displayGroup == dg) || (listDyn[i].displayGroup == 10)) {

  	DynVisObj* e = &listDyn[i];

  	switch (e->type) {

		case MONSTER:
				if (e->alive[NKClib_page] == TRUE) {
					e->xPos = e->xPos + (xStepSize * direction); 	
					e->isDirty[0] = TRUE;	
					e->isDirty[1] = TRUE;	
				}
				break;
					
		case UP_FIRE:	
				if (e->alive[NKClib_page] == TRUE) {
					e->yPos = e->yPos + e->accel;  
					e->accel+=5;

				 	if (e->yPos > 238) {			//out of screen
				 		e->alive[NKClib_page] = FALSE;
				 		addDynObj(BANG, listDyn[i].xPos-8, 238-10, (byte *)&Bang);
				 	}
				}
			 	break;  

		case DOWN_FIRE:	
				if (e->alive[NKClib_page] == TRUE) {
					e->yPos = e->yPos - 4;  //4

				 	if (e->yPos < 10) {				//out of screen
				 		e->alive[NKClib_page] = FALSE;
				 		addDynObj(BANG, listDyn[i].xPos-8, 10, (byte *)&Bang);
				 	}
			 	}
			 	break;

		case PLAYER: 	
				e->xPos = xPosPlayer;
				break;

		case UFO:
				if (e->alive[NKClib_page] == TRUE) {
					if ((e->xPos < 10) || (e->xPos > 500)) {				
				 		e->alive[NKClib_page] = FALSE;
				 		addToSoundBuffer(&soundBufferA, super_sonic_OFF, sizeof(super_sonic_OFF));
				 	}
				 	e->xPos = e->xPos + (5 * UFOdirection); 
				}

		}
  	}
  }

   	//collect Monster stats
	maxX = 0;
	minX = 999;
	minY = 999;

	noOfMonstersAlive = 0;

	for (int i=0; i <= noOfDynObj; i++) {

		DynVisObj* e = &listDyn[i];

		if (e->type == MONSTER) {
			//if (e->alive == TRUE) {
				if (e->xPos > maxX) maxX = e->xPos;
				if (e->xPos < minX) minX = e->xPos;
				if (e->yPos < minY) minY = e->yPos;
				noOfMonstersAlive++;
			//}
		}
	}

	// flip Monster direction and make vertical step 
	if (frame == 5) {
		if ((direction == 1) && (maxX > bounceRight)) {
			direction = -1;
			for (int i=0; i <= noOfDynObj; i++) {
				//if (listDyn[i].displayGroup == dg) {
					if (listDyn[i].type == MONSTER) {
						listDyn[i].yPos += yStepSize;
						listDyn[i].isDirty[0] = TRUE;	
						listDyn[i].isDirty[1] = TRUE;	
					}
				//}
			}
		} 

		if ((direction == -1) && (minX < bounceLeft)) {
			direction = 1;
			for (int i=0; i <= noOfDynObj; i++) {
				//if (listDyn[i].displayGroup == dg) {
					if (listDyn[i].type == MONSTER) {
						listDyn[i].yPos += yStepSize;
						listDyn[i].isDirty[0] = TRUE;	
						listDyn[i].isDirty[1] = TRUE;	
					}
				//}
			}
		}
	}

	//restart if too low
	if (minY < bounceLow) {   
		gameStats.noOfLives--;
		restartLevel = TRUE;
	}

}

void updateGameScore(int val) {
	
	gameStats.score += val;

 	text_score[0] = numbers[((gameStats.score/1000) % 10) * 2];
	text_score[1] = numbers[((gameStats.score/100) % 10) * 2];
	text_score[2] = numbers[((gameStats.score/10) % 10) * 2];
	text_score[3] = numbers[((gameStats.score/1) % 10) * 2];
	text_score[4] = 0x00;
}

void doCollisions() {
 
  for (int i=0; i <= noOfDynObj; i++) {

	//DynVisObj* e = &listDyn[i];

  	if (listDyn[i].type == UP_FIRE) {
  		
		DynVisObj* UpFireObj = &listDyn[i];

 		for (int p=0; p <= noOfDynObj; p++) { 

 			//upfire vs. UFO
			if (listDyn[p].type == UFO) {

				DynVisObj* UFOObj = &listDyn[p];

				if (hitUFO(UpFireObj->xPos, UpFireObj->yPos, 	
						   UFOObj->xPos,    UFOObj->yPos)) {	

					//update UFO
					UFOObj->alive[NKClib_page] = FALSE; 
 					UFOObj->isDirty[0] = TRUE;
 					UFOObj->isDirty[1] = TRUE;

					UpFireObj->alive[NKClib_page] = FALSE; 

					//do game related stuff
					addToSoundBuffer(&soundBufferA, super_sonic_OFF, sizeof(super_sonic_OFF));
					flash_text[0] = 0x30 + UFOObj->score;  //1..5 update text with UFO score
					addDynObj(FLASHTEXT, UFOObj->xPos, UFOObj->yPos, (byte *)&flash_text);
					updateGameScore(UFOObj->score * 100);
					break;
				}
			}

 			//upFire vs. Monster
  			if (listDyn[p].type == MONSTER)  {

  				DynVisObj* MonsterObj = &listDyn[p];

	  			if (listDyn[i].alive[NKClib_page] == TRUE) {

	  				if (hitMonster(UpFireObj->xPos,  UpFireObj->yPos, 	
								   MonsterObj->xPos, MonsterObj->yPos)) {	

						addToSoundBuffer(&soundBufferA, sound_upFire_ChannelA, sizeof(sound_upFire_ChannelB));
						
						//update Monster
	 					MonsterObj->alive[NKClib_page] = FALSE; 
	 					MonsterObj->isDirty[0] = TRUE;
	 					MonsterObj->isDirty[1] = TRUE;

	 					UpFireObj->alive[NKClib_page] = FALSE; 
	 					//listDyn[i].alive[!NKClib_page] = FALSE; //fire
	 					
	 					//do game related stuff
	 					addDynObj(BANG, MonsterObj->xPos, MonsterObj->yPos, (byte *)&Bang);
	 					updateGameScore(MonsterObj->score);
	 					break;
	  				}			
	  			}
  			}
  		}

  		//upfire vs. bunker from below
		if (listDyn[i].yPos < 46) {   //check if fire is down at bunker level

			for (int p=noOfStatObj; p > 0; p--) {  //move backwards through list, scan bunkerhits from below ??????

				if (listStat[p].type == BUNKER) {  //also text objects in list

					if (listStat[p].alive == TRUE) {  

						if (hitBunker(listDyn[i].xPos,  listDyn[i].yPos, 	//Fire pos
									  listStat[p].xPos, listStat[p].yPos)) {//Bunker pos
			
							listDyn[i].alive[NKClib_page] = FALSE; //fire
							//listDyn[i].alive[!NKClib] = FALSE; //fire
							
							//Bunker
							listStat[p].alive = FALSE;
							listStat[p].isDirty[NKClib_page] = TRUE;
							listStat[p].isDirty[!NKClib_page] = TRUE;
							break;  //no more nesessary
						}
					}	
				}	
			}
		}
  	}


	if (listDyn[i].type == DOWN_FIRE) {

		DynVisObj* DownFireObj = &listDyn[i];

		if (DownFireObj->yPos < 46) {   //bunker and player should be below y46

			//downfire fire vs. player
			for (int p=0; p <= noOfDynObj; p++) {

	  			if (listDyn[p].type == PLAYER) {   

	  				if (DownFireObj->yPos < yPosPlayer+7) {  //check if fire is low enough

		  				if ((DownFireObj->xPos >= xPosPlayer) && (DownFireObj->xPos <= xPosPlayer+34)) {
							addToSoundBuffer(&soundBufferA, super_sonic_OFF, sizeof(super_sonic_OFF));
							playSound(1);   //to get sonic_off processed 
							CMD(0x08);  //FLASH
		 					DownFireObj->alive[NKClib_page] = FALSE; 
		 					gameStats.noOfLives--;
							restartLevel = TRUE;
		  				}
		  			}
		  			break;
	  			}
	  		}

			//downfire fire vs. bunker
			for (int p=0; p <= noOfStatObj; p++) {  //move forward through list

				if (listStat[p].type == BUNKER) {  

					StatVisObj* BunkerObj = &listStat[p];

					if (BunkerObj->alive == TRUE) {  

						if (hitBunker(DownFireObj->xPos, DownFireObj->yPos, 	
									  BunkerObj->xPos,   BunkerObj->yPos)) {

							//update downfire
							//listDyn[i].alive[NKClib_page] = FALSE; //fire
							DownFireObj->alive[!NKClib_page] = FALSE; //fire  which one ?

							//update bunkerblock
							BunkerObj->alive = FALSE; 
							BunkerObj->isDirty[NKClib_page] = TRUE;
							BunkerObj->isDirty[!NKClib_page] = TRUE;
							break;  //no more
						}
					}			
				}	
			}
		}
	}
  }

	//erase bunkers if Monster very low
	/*if (minY < 45) {  
		for (int p=0; p<96; p=p+24) {
			for (int i=0+p; i < 21+p; i=i+4) {	//first bunker rwo
				listStat[i].alive = FALSE;  listStat[i].isDirty[NKClib_page] = TRUE; 	listStat[i].isDirty[!NKClib_page] = TRUE;
			}
		}
	}	
	if (minY < 41) {  
		for (int p=0; p<96; p=p+24) {
			for (int i=1+p; i < 22+p; i=i+4) {	//second bunker row
				listStat[i].alive = FALSE;  listStat[i].isDirty[NKClib_page] = TRUE; 	listStat[i].isDirty[!NKClib_page] = TRUE;
			}
		}
	}
	if (minY < 37) {  
		for (int p=0; p<96; p=p+24) {
			for (int i=2+p; i < 23+p; i=i+4) {	//third bunker row
				listStat[i].alive = FALSE;  listStat[i].isDirty[NKClib_page] = TRUE; 	listStat[i].isDirty[!NKClib_page] = TRUE;
			}
		}
	}
	if (minY < 33) {
		for (int p=0; p<96; p=p+24) {
			for (int i=3+p; i < 24+p; i=i+4) {	//fourth bunker row
				listStat[i].alive = FALSE;  listStat[i].isDirty[NKClib_page] = TRUE; 	listStat[i].isDirty[!NKClib_page] = TRUE;
			}
		}
	}*/
}



void gameIntro() {
 
 	static const byte lineTM[10] = {"TM"};
	static const byte line0[40] = {"  0000"};
	static const byte line1[10] = {"PLAY"};   					//4		
	static const byte line2[25] = {"SPACE  INVADERS"};			//15    
	static const byte line3[25] = {"* SCORE ADVANCE TABLE *"};   //23    
	static const byte line4[20] = {"=? MYSTERY"};				//10     
	static const byte line5[20] = {"=30 POINTS"}; 
	static const byte line6[20] = {"=20 POINTS"}; 
	static const byte line7[20] = {"=10 POINTS"}; 
	static const byte line8[35] = {"(TM) 1978 Kabushiki Kaisha Taito"};  //26
	static const byte line9[20] = {"(GPL) 2019 smed"};				  //12
	//byte lineX[30] = {"                           "};				  //12

	GDP_WAIT();
  	GDP_PAGE_REG = 0b11110000;

	GDP_CSIZE(0x11);

	//scroll-in lines
	for (int i=40; i > 0; i--) {
		CMD(0x00);
		CMDPRINT3(((512 - (26 * 6)+1) / 2)-10, 10-(i/2), (byte *)&line8);
		CMDPRINT3(((512 - (12 * 6)+1) / 2)-10,  0-(i/2), (byte *)&line9);
		WAIT(3);

		GDP_SYNC_IT(); 
		CMD(0x01);
		CMDPRINT3(((512 - (26 * 6)+1) / 2)-10, 10-(i/2), (byte *)&line8);
		CMDPRINT3(((512 - (12 * 6)+1) / 2)-10, 0-(i/2), (byte *)&line9);
	}

	CMD(0x00);
	CMDPRINT3(((512 - (26 * 6)+1) / 2)-10, 10, (byte *)&line8);
	CMDPRINT3(((512 - (12 * 6)+1) / 2)-10,  0, (byte *)&line9);

	WAIT(7*10);

	GDP_CSIZE(0x31);
	CMDPRINT3(  0, 247, (byte *)&text_topLine);
	CMDPRINT3(  0, 235, (byte *)&line0);   //score
	CMDPRINT3(234, 235, (byte *)&text_highScore); 

	CMDPRINT3SLOW(   (512 - ( 4 * 18)+1) / 2, 200, (byte *)&line1, 6);

	GDP_CSIZE(0x34);
	CMDPRINT3SLOW(   (512 - (15 * 18)+1) / 2, 155, (byte *)&line2, 10);

	GDP_CSIZE(0x11);
	CMDPRINT3SLOW(   388, 183, (byte *)&lineTM, 5);
	GDP_CSIZE(0x31);

	CMDPRINT3(   (512 - (23 * 18)+1) / 2, 130, (byte *)&line3);

	CMDPRINT3(      ((512 - ((10+2) * 18)+1) / 2) - 16, 95+15, (byte *)&UFOA);
	CMDPRINT3(      ((512 - ((10+2) * 18)+1) / 2) - 8, 80+15, (byte *)&monsterA1);
	CMDPRINT3(      ((512 - ((10+2) * 18)+1) / 2) - 8, 65+15, (byte *)&monsterB1);
	CMDPRINT3(      ((512 - ((10+2) * 18)+1) / 2) - 8, 50+15, (byte *)&monsterC1);

	WAIT(5*10);

	CMDPRINT3SLOW( 22 + (512 - ((10+2) * 18)+1) / 2, 95+15, (byte *)&line4, 10);
	CMDPRINT3SLOW( 22 + (512 - ((10+2) * 18)+1) / 2, 80+15, (byte *)&line5, 10);
	CMDPRINT3SLOW( 22 + (512 - ((10+2) * 18)+1) / 2, 65+15, (byte *)&line6, 10);
	CMDPRINT3SLOW( 22 + (512 - ((10+2) * 18)+1) / 2, 50+15, (byte *)&line7, 10);
	
	waitForJoystickFire();	//will call catchSync()

	//init random generator
	prev = syncCounter % 100;
	pageFlip_2();  
}

void gameOver() {

	//print scores
	GDP_CSIZE(0x31);
	CMDPRINT3( 20, 238, (byte *)&text_score); 
	CMDPRINT3(234, 238, (byte *)&text_highScore); 

	//print exit screen
  	GDP_CSIZE(0x52);
  	byte text[10] = {"GAME OVER"};
	CMDPRINT3(120, 128, &text[0]); 
	pageFlip_2();  

	WAIT(10*30);

	if (gameStats.score > gameStats.highScore) {
  		gameStats.highScore = gameStats.score;
		text_highScore[0] = numbers[((gameStats.score/1000) % 10) * 2];
		text_highScore[1] = numbers[((gameStats.score/100) % 10) * 2];
		text_highScore[2] = numbers[((gameStats.score/10) % 10) * 2];
		text_highScore[3] = numbers[((gameStats.score/1) % 10) * 2];
		text_highScore[4] = 0x00;
	}
	gameStats.score	= 0;
	text_score[0] = 0x30;
	text_score[1] = 0x30;
	text_score[2] = 0x30;
	text_score[3] = 0x30;
	text_score[4] = 0x00;

	joystickFireAllowed = TRUE;
}

void drawStaticText() {

  	GDP_CSIZE(0x31); 
    
    for (int i=0; i < 2; i++) {
	  	
	  	pageFlip_2();   
		CMDPRINT3(  0, 247, &text_topLine[0]);
		CMDPRINT3(350,   0, &text2_botLine[0]);

		CMDPRINT3(  0,   0, &numbers[gameStats.noOfLives*2]);    //lives

		//draw noOfLives at bottom
 		GDP_CSIZE(0x71); 
		for (int p = 0; p < gameStats.noOfLives; p++)
		{
			CMDPRINT3(30 + (p * 45), -2, &player[0]);
			CMD(0x00);
		}

 		GDP_CSIZE(0x31); 

		GDP_MOVETO(0, 9);
		GDP_HLINE(0xFF);
		GDP_HLINE(0xFF);
	}

 	GDP_CSIZE(0x21);
}


/*void debug() {

	byte buffer = GDP_PAGE_REG;
	GDP_PAGE_REG = 0b00000000; 
	GDP_SYNC_POS();
	
	consoleArgs.x = 0; consoleArgs.y = 254-6;

	GDP_CLS();
	DebugPrint(".text :", (int)&_text_sta, HEX);
	DebugPrint("      :", (int)&_text_end, HEX);
	DebugPrint("  size:", (int)&_text_end - (int)&_text_sta, DEC);

	DebugPrint(".data :", (int)&_data_sta, HEX);
	DebugPrint("      :", (int)&_data_end, HEX);
	DebugPrint("  size:", (int)&_data_end - (int)&_data_sta, DEC);

	DebugPrint(".bss :", (int)&_bss_sta, HEX);
	DebugPrint("     :", (int)&_bss_end, HEX);
	DebugPrint("  size:", (int)&_bss_end - (int)&_bss_sta, DEC);

	DebugPrint("NMI handler:", (int)&_int_handler_sta, HEX);

	maxCountsPerHSYNC = getMaxCountsToVSYNC();  
	DebugPrint("Counts/HSYNC: ", maxCountsPerHSYNC, DEC);
	
	DebugPrint("noOfLives", gameStats.noOfLives, 	DEC);
	DebugPrint("level", 	gameStats.level, 		DEC);
	
	DebugPrint("page", 		NKClib_page, 		DEC);
	DebugPrint("direction", direction	, 		DEC);

	DebugPrint("xStepSize", xStepSize	, 		DEC);
	DebugPrint("yStepSize", yStepSize	, 		DEC);

	DebugPrint("score", 	gameStats.score, 		DEC);
	DebugPrint("frame", 	frame, 					DEC);
	DebugPrint("tick", 	    tick, 					DEC);
	DebugPrint("lstFired", 	lastTickFired, 			DEC);

	DebugPrint("joyFireAllowed", (int)DebugPrint, DEC);

	DebugPrint("xPosPlayer",xPosPlayer, 			DEC);
	
	
	//DebugPrint("bounceRight", bounceRight	, 		DEC);
	//DebugPrint("bounceLeft",  bounceLeft	, 		DEC);
	//DebugPrint("bounceLow",   bounceLow	    , 		DEC);

	//DebugPrint("consoleArgs.x", consoleArgs.x, 		DEC);
	//DebugPrint("consoleArgs.y", consoleArgs.y, 		DEC);

	DebugPrint("noOfDynObj",noOfDynObj, 			DEC);
	int buf = noOfDynObj;
	int i = 0;
	//while (i < buf) {
	//	DebugPrint("-x", listDyn[i].xPos, DEC);
	//	DebugPrint("-y", listDyn[i].yPos, DEC);
	//	i++;
	//}

	//int sizeDynObj = sizeof(DynVisObj);
	//int sizeDynObjList = sizeof(listDyn);
	//DebugPrint("noOfDynObj_", sizeDynObjList / sizeDynObj, DEC);

	//DebugPrint("MonsterA1:", zzz((byte *)&monsterA1), DEC);
	//DebugPrint("MonsterA2:", zzz((byte *)&monsterA2), DEC);

	DebugPrint("prev", prev, DEC); //RND
	DebugPrint("result", result, DEC);
	WAIT(400);   //4sec
	GDP_CLS();

	GDP_PAGE_REG = buffer;

} */


void processKeyboard() {

	//byte theKey = readKey();

  	//if (theKey != 0) {  
	if (gp_csts()) {
    	//theKey = readKey();
    	//theKey = theKey - 128;
		const byte theKey = gp_ci();
    	
  		switch (theKey) {

  			case 'a':
				xPosPlayer-=5;
  				break;

  			case 'l':
				  joystickAccel = abs(joystickAccel) * -1;
  				  xPosPlayer+=5;
  				break;

			case 'x':
				gameOn = FALSE;
  				break;

			case ' ':
				doJoystickFire();
				//DebugPrintPos(220, 0, "Use Joystick", 0, NONE);
  				break;

  			case 't':
  				measureFramerate = TRUE;
  			break;

  			case 'd':
  				printDynVisObjList();
  				//debug();WAIT(5);
			case 0x13: // Arrow-left
			    doJoystickLeft();
				break;
			case 04: // Arrow-right
			    doJoystickRight();
				break;
  			break;

  		}
	}
}
/*
void CI() {  

	byte key;
	
	do {
		key = KEY_REG;
	} while ((key && STROBE) != STROBE);
//	return gp_ci();
}*/


void printDynVisObjList() {

 	GDP_WAIT();
    byte buffer = GDP_PAGE_REG;
    GDP_PAGE_REG = 0b11110000;
    GDP_CLS();

    DebugPrintPos(0, 255-7, "t    f       xpos alive   ", 0, NONE);

    int Y = 255-20;

	DebugPrintPos( 0, Y, "noOfDynObj", noOfDynObj, DEC); 
	Y = Y - 8;

	for (int i=0; i <= noOfDynObj; i++) {  

		DynVisObj* e = &listDyn[i];

	  if (e->type == DOWN_FIRE) {

  		//DebugPrintPos( 0, Y, "t:", tick, DEC); 
  		//DebugPrintPos(30, Y, "f:", frame, DEC); 
    	//DebugPrintPos(50, Y, "X:", e->xPos, DEC); 
		
		//DebugPrintPos(100, Y, "a0", e->alive[0], DEC); 
    	//DebugPrintPos(125, Y, "a1", e->alive[1], DEC); 

    	//DebugPrintPos(120, Y, "", e->ypos, DEC); 

		//DebugPrintPos(100, Y, "", (int)e->cmdList[0], HEX);
		//DebugPrintPos(180, Y, "", (int)e->cmdList[1], HEX); 

		//if (e->alive[NKClib_page] == TRUE) {
		//	DebugPrintPos(260, Y, "a:Y", (int)e->alive[NKClib_page], NONE);
		//} else {
		//	DebugPrintPos(260, Y, "a:N", (int)e->alive[NKClib_page], NONE);
		//}


		//DebugPrintPos(340, Y, "", (int)e->cmdListPage[1], HEX); 

		//DebugPrintPos(400, Y, "", (int)e->isDirty, DEC);


		//DebugPrintPos(180, Y, "dg:", (int)e->displayGroup, DEC);
		DebugPrintPos(220, Y, "x:", e->xPos, DEC);
		DebugPrintPos(260, Y, "y:", e->yPos, DEC);

		Y = Y - 8;
	  }
 	}

    DebugPrintPos(260, Y, " dyn #:", noOfDynObj,  DEC);
	Y = Y - 8;
  	DebugPrintPos(260, Y, "stat #:", noOfStatObj, DEC);
	Y = Y - 8;

	DebugPrintPos(260, Y, "d :", listDyn[noOfDynObj].type, DEC);
	Y = Y - 8;  
	DebugPrintPos(260, Y, "d-:", listDyn[noOfDynObj+1].type, DEC);
	Y = Y - 8;

	DebugPrintPos(260, Y, "s :", listStat[noOfStatObj].type, DEC);
	Y = Y - 8;  
	DebugPrintPos(260, Y, "s-:", listStat[noOfStatObj+1].type, DEC);
	Y = Y - 8;



 	/*for (int i=0; i <= noOfStatObj; i++) {  

		StatVisObj* e = &listStat[i];

		if (e->type == BUNKER) {
			if (e->alive == TRUE) {
				DebugPrint(":", e->xPos, DEC);
				DebugPrintPos(260, Y, "y:", e->yPos, DEC);
				Y = Y - 8;
			}
		}
    }*/

	WAIT(10*30);
 	GDP_WAIT();
 	GDP_PAGE_REG = buffer;
 	GDP_WAIT();
}

#if 0
int volatile initMemory() {

	//clear BSS section
	int *text_sta = &_text_sta;
	int *bss_start = &_bss_sta;
	int *bss_end   = &_bss_end;

	int size = bss_end - bss_start;	
	memset(bss_start, 0x00, size);

	maxCountsPerHSYNC = getMaxCountsToVSYNC();  
}
#endif

int main(void) {

	//init_interrupt();
	//interrupt_OFF();
 	//initMemory(); 
	//gp_clearscreen();
    //GDP_WAIT();
	gp_cursor_off();
    gp_setflip(0u,0u);

// 	while (TRUE) {

	initGraphics(); 
	
	pageFlip_2(); 
	
	initSound();

	consoleArgs.x = 0; consoleArgs.y = 254-6; consoleArgs.fontSize = 0;
	
	//joystickAccel = 1;
	//joystickAccelInc = 4;
	//minJoystickAccel = 4;
	//maxJoystickAccel = 20;

	gameStats.noOfLives = 3;
	gameStats.level = 1;
	gameStats.score	= 0;
	
	//zero init variables;	
	tick=0;
	frame = 1;   //must starst at 1, for sprite change all 5 frames with %
    counter = 0;
    xPosPlayer = 245;
		    
	gameOn = TRUE;

	gameIntro();

	initObj();
	
	//clear screen and start
	GDP_CLS(); pageFlip_2(); 
	GDP_CLS(); pageFlip_2();
	drawStaticText(); pageFlip_2(); 
	drawStaticText(); pageFlip_2(); 
	

	GDP_SYNC_POS();  //sync game loop

	while (gameOn) {	

		syncCounter = 0; 					//asm("move.b 0x00, 0x8000");

		processKeyboard(); 					//asm("move.b 0x00, 0x8007");
		processJoystick(); 					//asm("move.b 0x00, 0x8008");

		doMovements(frame); catchSync(); 	//asm("move.b 0x00, 0x8001");
		
		doAction();         catchSync(); 	//asm("move.b 0x00, 0x8002");
		doCollisions();     catchSync(); 	//asm("move.b 0x00, 0x8003");

		clearDynObj();      catchSync(); 	//asm("move.b 0x00, 0x8004");
		drawDynObj();       catchSync(); 	//asm("move.b 0x00, 0x8005");

		drawStatObj();      catchSync();  	//asm("move.b 0x00, 0x8006");
	
		pageFlip_2();   					//asm("move.b 0x00, 0x800F");	
		
		
		tick++;
		frame++; 
		if (frame == 6) {
			if (toggle == TRUE) {
				doSpecialEffects();
				godKonwsWhy();
			}
			toggle = !toggle;
			frame = 1;           //must start at 1
		} 

		if (!UFOactive) {
			if (getRandom() > 98) {    
				if (getRandom() > 50) {
					UFOactive = TRUE;
					if (getRandom() > 50) {
						UFOxPos = 0;
						UFOdirection = 1;
					} else {
						UFOxPos = 512 - UFOwidth;
						UFOdirection = -1;
					}
					addDynObj(UFO, UFOxPos, UFOyPos, (byte *)(&UFOA));  
					addToSoundBuffer(&soundBufferA, super_sonic, sizeof(super_sonic));
				}
			}
		}

 		if (measureFramerate == TRUE) {

 			counts = countToVSYNC(); 

			DebugPrintPos(450, 240, "          ", 0, DEC);	
			DebugPrintPos(450, 240, "s: ", syncCounter, DEC);
			DebugPrintPos(450, 230, "          ", 0, DEC);	
			DebugPrintPos(450, 230, "c: ", counts, DEC);	
			DebugPrintPos(450, 220, "          ", 0, DEC);	
			DebugPrintPos(450, 220, "%: ", (counts * 100) / maxCountsPerHSYNC, DEC);	
			pageFlip_2();    

			DebugPrintPos(450, 240, "          ", 0, DEC);	
			DebugPrintPos(450, 240, "s: ", syncCounter, DEC);
			DebugPrintPos(450, 230, "          ", 0, DEC);	
			DebugPrintPos(450, 230, "c: ", counts, DEC);	
			DebugPrintPos(450, 220, "          ", 0, DEC);	
			DebugPrintPos(450, 220, "%: ", (counts * 100) / maxCountsPerHSYNC, DEC);	
			pageFlip_2();    

 			measureFramerate = FALSE;
 		}
		 
	 	if (restartLevel == TRUE) {
	 		
			addToSoundBuffer(&soundBufferA, super_sonic_OFF, sizeof(super_sonic_OFF));
			playSound(1);    
			clearSoundQueue();
			playSound(1); 

			//ticks=0;
			lastTickFired = 0;
			noOfDynObj = 0;
		    frame = 1;  
		    counter = 0;
		    xPosPlayer = 245;
		    direction = 1;
		    UFOactive = FALSE;
		    restartLevel = FALSE;
 	
			initObj();	
		
			GDP_CLS(); pageFlip_2(); 
			GDP_CLS(); pageFlip_2();
			drawStaticText(); pageFlip_2(); 
			drawStaticText(); pageFlip_2(); 

			if (gameStats.noOfLives == 0) {
				gameOn = FALSE;
			} else {
				text_level[6] = 0x30 + gameStats.level;
				text_level[7] = 0x00;
				GDP_CSIZE(0x31);
				CMDPRINT3(170, 150, text_level);
				pageFlip_2();
				WAIT(4*30);
				pageFlip_2();
				CMD(0x01);
				CMDPRINT3(170, 150, text_level);
				CMD(0x00);
			}
		}

		#if simulatePlayer
			
			//left-right movement
			if (getRandom() > 50) { 
				if (getRandom() > 50) {
					xPosPlayer-=4; } 
				else { 
					xPosPlayer+=4; }
			}

			//fire, but keep under 5 bullets
			if (getRandom() > 95) {
				if (getNoOfDynObj(UP_FIRE) < 3) {
					addDynObj(UP_FIRE, xPosPlayer+10, 20, (byte *)&fire);
				}
			}

			if (xPosPlayer < 0)   xPosPlayer = 256;
			if (xPosPlayer > 511) xPosPlayer = 256;
		#endif 
	}		
	gameOver();
//}
	gp_clearscreen();
}