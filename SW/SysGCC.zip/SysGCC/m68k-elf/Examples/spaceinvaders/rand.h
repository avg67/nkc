//https://github.com/eblot/newlib/blob/master/newlib/libc/stdlib/rand.c

static int _seed;

void __srand() {

//000006dc <srand>:
 	asm("linkw %fp,#0"); 				//6dc:	4e56 0000      	linkw %fp,#0
 	//asm("moveal _seed,%a0"); 	//6e0:	2079 0000 080c 	moveal 80c <_data_sta>,%a0
 	asm("movel %fp@(8),%a0@(164)"); 	//6e6:	216e 0008 00a4 	movel %fp@(8),%a0@(164)
 	asm("clrl %a0@(160)"); 				//6ec:	42a8 00a0      	clrl %a0@(160)
 	asm("unlk %fp"); 					//6f0:	4e5e           	unlk %fp
 	asm("rts"); 						//6f2:	4e75           	rts
}

void __rand() {
//000006dc <rand>:
 	asm("linkw %fp,#0"); 				// 6dc:	4e56 0000      	linkw %fp,#0
 	asm("movel %a2,%sp@-"); 			// 6e0:	2f0a           	movel %a2,%sp@-
 	asm("movel %d2,%sp@-"); 			// 6e2:	2f02           	movel %d2,%sp@-
 	//asm("moveal _seed,%a2"); 	// 6e4:	2479 0000 07ec 	moveal 7ec <_data_sta>,%a2
 	asm("movel #1284865837,%sp@-"); 	// 6ea:	2f3c 4c95 7f2d 	movel #1284865837,%sp@-
 	asm("movel #1481765933,%sp@-"); 	// 6f0:	2f3c 5851 f42d 	movel #1481765933,%sp@-
 	asm("movel %a2@(164),%sp@-"); 		// 6f6:	2f2a 00a4      	movel %a2@(164),%sp@-
 	asm("movel %a2@(160),%sp@-"); 		// 6fa:	2f2a 00a0      	movel %a2@(160),%sp@-
 	//asm("jsr __muldi3"); 				// 6fe:	4eb9 0000 0744 	jsr 744 <__muldi3>
 	asm("lea %sp@(16),%sp"); 			// 704:	4fef 0010      	lea %sp@(16),%sp
 	asm("clrl %d2"); 					// 708:	4282           	clrl %d2
 	asm("addql #1,%d1"); 				// 70a:	5281           	addql #1,%d1
 	asm(" addxl %d2,%d0"); 				// 70c:	d182           	addxl %d2,%d0
 	asm("movel %d0,%a2@(160)"); 		// 70e:	2540 00a0      	movel %d0,%a2@(160)
 	asm("movel %d1,%a2@(164)"); 		// 712:	2541 00a4      	movel %d1,%a2@(164)
 	asm("bclr #31,%d0"); 				// 716:	0880 001f      	bclr #31,%d0
 	asm("movel %fp@(-8),%d2"); 			// 71a:	242e fff8      	movel %fp@(-8),%d2
 	asm("moveal %fp@(-4),%a2"); 		// 71e:	246e fffc      	moveal %fp@(-4),%a2
 	asm("unlk %fp"); 					// 722:	4e5e           	unlk %fp
 	asm("rts"); 						// 724:	4e75           	rts
 }