#ifndef NKC_JOYSTIC_H
#define NKC_JOYSTIC_H

//#define IOE_PORTA BYTE_AT(0xFFFFFF30)
//#define IOE_PORTB BYTE_AT(0xFFFFFF31)

#define JOYSTICK_LEFT  0xFE  //bit 0
#define JOYSTICK_RIGHT 0xFD  //bit 1
#define JOYSTICK_UP    0xFB  //bit 2
#define JOYSTICK_DOWN  0xF7  //bit 3
#define JOYSTICK_FIRE  0xEF  //bit 4

//to be defined in main file
/*
void doJoystickLeft();
void doJoystickRight();
void doJoystickUp();
void doJoystickDown();
void doJoystickFire();
*/

void processJoystick() {

	word IOEports = readIOEports();
	byte joystick = (byte)IOEports;

	if (joystick == 0xFF) {
		//joystick not used, reset all dynamics
		joystickRamp = 0,
		joystickAccel = minJoystickAccel;
		joystickFireAllowed = TRUE;

	} else {

		if (joystickRamp >= 0) {
			if (joystickAccel < maxJoystickAccel) {
				joystickAccel+=joystickAccelInc;
				joystickRamp = 0;
			}
		} else {
			joystickRamp++;
		}

		if ((~joystick & ~JOYSTICK_LEFT) == ~JOYSTICK_LEFT)	{
			//joystickAccel = abs(joystickAccel) * -1;
			doJoystickLeft();
		}

		if ((~joystick & ~JOYSTICK_RIGHT) == ~JOYSTICK_RIGHT) {
			doJoystickRight();
		}

		/*if ((~joystick & ~JOYSTICK_UP) == ~JOYSTICK_UP)	{
			doJoystickUp();
		}

		if ((~joystick & ~JOYSTICK_DOWN) == ~JOYSTICK_DOWN)	{
			doJoystickDown();
		}*/

		if ((~joystick & ~JOYSTICK_FIRE) == ~JOYSTICK_FIRE)	{
			//DebugPrintPos(100, 100, "             ", joystickRamp, NONE);
			//DebugPrintPos(100, 100, "", joystickRamp, DEC);
			if (joystickFireAllowed) {  //to avoid Dauerfeuer
				if ((tick - lastTickFired) > dauerfeuerprevent) {
					doJoystickFire();
			 		lastTickFired = tick;
				}
				joystickFireAllowed = FALSE;
			}

		} else {
			//fire not pressed, reset all dynamic values
			joystickFireAllowed = TRUE;
			
		}
	}
	//DebugPrintPos(100, 100, "", joystickRamp, DEC);

	processKeyboard();
}

void waitForJoystickFire() {

	word IOEports;
	byte joystick;
	byte key;

	do {

		IOEports = readIOEports();
		joystick = (byte)IOEports;

		//key = readKey();
		key = gp_ci(); //readKey();
		//key = key - 128;
		if (key == ' ') {joystick = JOYSTICK_FIRE;}

		catchSync();

	} while ((~joystick & ~JOYSTICK_FIRE) != ~JOYSTICK_FIRE);
}
#endif
