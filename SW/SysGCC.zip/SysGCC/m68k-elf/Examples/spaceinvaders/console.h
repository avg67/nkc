
//  console.h
//typedef unsigned short word; // .w

//sould be merged into NKC_UTIL.h

int result = 0;
int prev = 42;

/*#ifdef old_random_func
void __attribute__ ((noinline)) mod_68k(int a, int b) {

	__asm__ __volatile__(
		"movel %1, %%d0\n\t"
		"movel %2, %%d1\n\t"
		
		"divu %%d1, %%d0\n\t"
		"clr.w %%d0\n\t"
		"swap %%d0\n\t"
		
		"movel %%d0, %0\n\t"
		
		: "=m"(result)  //
		: "r"(a), "r"(b) //
		: "d0"// 
	);

// access to C Variables:
   //use .l to access int
   //use .w to access word
//
}

void bar(word *loc) {

	__asm__ __volatile__(

	"movea %0, %%a0\n\t"
	"add #1, (%%a0)\n\t"
		:  
		: "r"(loc) 
		: "a0"
	);
}
word foo(word valueA) {

	register long res  __asm__("%d5");

	__asm__ __volatile__(
		"move 0, %%d5\n\t"
		//"add #1, d0\n\t"
		//"move d0, %1\n\t"
		//"clr.w d1\n\t"
		//"swap d1\n\t"

		: "=r"(res)  // OUTPUTS 
		: "r"(valueA) // INPUTS 
		: // CLOBBERS 
	);

	return res;
} 
#endif
*/

//returns number between 0 and 99
int getRandom() {
	
	int a = prev;

	//mod_68k(7 * a, 997);  //this changes 'result'
	result = (29*a) % 5003;

	prev = result;

	//mod_68k(result - 1, 100);
	result = (result % 100) - 1;

	return result+1;
}